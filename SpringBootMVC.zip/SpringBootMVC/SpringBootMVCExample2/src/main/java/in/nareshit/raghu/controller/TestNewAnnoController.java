package in.nareshit.raghu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TestNewAnnoController {

	@GetMapping("/show")
	public String showInfo() {
		return "Home";
	}
	//@RequestMapping(value = "/save",method = RequestMethod.POST)
	@PostMapping("/save")
	public String saveData() {
		return "Data";
	}
}
