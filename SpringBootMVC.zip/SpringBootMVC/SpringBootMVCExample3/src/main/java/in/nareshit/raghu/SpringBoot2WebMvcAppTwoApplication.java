package in.nareshit.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2WebMvcAppTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2WebMvcAppTwoApplication.class, args);
	}

}
