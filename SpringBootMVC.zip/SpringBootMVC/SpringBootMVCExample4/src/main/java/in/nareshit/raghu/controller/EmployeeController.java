package in.nareshit.raghu.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nareshit.raghu.model.Employee;

@Controller
public class EmployeeController {

	@RequestMapping("/show")
	public String showData(Model model) {
		
		List<Employee> list = List.of(
					new Employee(101, "sandip", 30000.30),
					new Employee(102, "Shubham", 50000.30),
					new Employee(103, "Madhu", 80000.30),
					new Employee(104, "Trupti", 20000.30)
				);
		model.addAttribute("emps", list);
		
		
		return "Result";
	}
}
