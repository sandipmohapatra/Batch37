package in.nareshit.raghu.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nareshit.raghu.model.Employee;

@Controller
@RequestMapping("/emp")
public class EmpController {
	
	
	@GetMapping("/reg")
	public String showFormWithData(Model model) 
	{
		Employee employee = new Employee();
		employee.setEmpId(1521);
		employee.setEmpName("SAM");
		employee.setEmpSal(6.636);
		model.addAttribute("employee", employee);
		return "EmpReg";
	}
	
	@PostMapping("/save")
	public String saveEmp(
			@ModelAttribute Employee employee,
			Model model)
	{
		model.addAttribute("obj", employee);
		return "EmpInfo";
	}
	

	@GetMapping("/home")
	public String showHome(
			Model model) 
	{
		model.addAttribute("eid", 101);
		model.addAttribute("ename", "abcdef");
		return "EmpHome";
	}
	
	@GetMapping("/data")
	public String showData(Model model) 
	{
		
		List<Employee> emps = List.of(
				new Employee(101, "Amit", 20000.2),
				new Employee(102, "Binay", 30000.2),
				new Employee(103, "Chaten", 40000.5),
				new Employee(104, "Dinesh", 20000.9)
				);
		model.addAttribute("emps", emps);
		return "EmpData";
	}
}
