package in.nareshit.raghu.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.service.IStudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private IStudentService service;
	
	//1. Show Register page
	@GetMapping("/register")
	public String showReg(Model model)
	{
		//Form Backing Object
		model.addAttribute("student", new Student());
		return "StudentRegister";
	}
	
	//2. Save Student
	@PostMapping("/save")
	public String save(
			@ModelAttribute Student student,
			Model model) 
	{
		Integer id = service.saveStudent(student);
		model.addAttribute("message", "Student '"+id+"' saved");
		//clear form
		model.addAttribute("student", new Student());
		return "StudentRegister";
	}
	
	//3. display all students
	//@GetMapping("/all")
	public String showAll(Model model) {
		List<Student> list = service.getAllStudent();
		model.addAttribute("list", list);
		return "StudentData";
	}
	
	//..../all?page=2&size=5
	//.../all (no input in URL)  => defaults page=0,size=10
	@GetMapping("/all")
	public String showPage(
			@PageableDefault(page = 0,size = 3) Pageable p,
			Model model) 
	{
		Page<Student> page = service.getPageStudent(p);
		model.addAttribute("page", page);
		return "StudentData";
	}
	
	
	
	
	
	
	//4. Delete one student
	//.../delete?id=__
	@GetMapping("/delete")
	public String delete(
			@RequestParam Integer id,
			Model model)
	{
		String message=null;
		if(service.isStudentExist(id)) {
			service.deleteStudent(id);
			message = "Student '"+id+"' Deleted";
		}else {
			message = "Student '"+id+"' not exist";
		}
		model.addAttribute("message", message);
		//fetch latest table data
		List<Student> list = service.getAllStudent();
		model.addAttribute("list", list);
		//send to UI
		return "StudentData";
	}
	
	//5. Show Edit Page
	//.../edit?id=__
	/**
	 * If given input id exist in database
	 * then goto Edit Page, else come to same page
	 * back to Data(all)
	 */
	@GetMapping("/edit")
	public String showEdit(
			@RequestParam Integer id,
			Model model) 
	{
		String page = null;
		Optional<Student> opt = service.getOneStudent(id);
		
		if(opt.isPresent()) {
			//if exist--goto edit page
			model.addAttribute("student", opt.get());
			page = "StudentEdit";
		}else { 
			//given id not exist in DB
			page ="redirect:all";
		}
		return page;
	}
	
	//6. Do Update
	@PostMapping("/update")
	public String update(
			@ModelAttribute Student student
			) 
	{
		//task-- read id, if id exist then update,send message
		// else--redirect to all page
		service.updateStudent(student);
		return "redirect:all";
	}
	
	//AJAX call method
	@GetMapping("/checkName")
	public @ResponseBody String validateName(
			@RequestParam String sname)
	{
		String message = "";
		if(service.isStudentNameExist(sname)) {
			System.out.println("YES");
			message = "Student '"+sname+"' already exist";
		}
		return message; //it is not a pageName
	}
	
	
}