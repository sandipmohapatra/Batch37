package in.nareshit.raghu.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nareshit.raghu.model.Student;

public interface StudentRepository 
	extends JpaRepository<Student, Integer> {

	@Query("SELECT COUNT(stdId) FROM Student WHERE stdName=:stdName")
	Integer getStudentNameCount(String stdName);
}
