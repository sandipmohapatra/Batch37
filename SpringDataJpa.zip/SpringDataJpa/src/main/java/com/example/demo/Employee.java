package com.example.demo;

import javax.persistence.*;

@Entity
@Table(name="marlabemployee22")
public class Employee {
	public Employee(String empName, Double empSal) {
		super();
		this.empName = empName;
		this.empSal = empSal;
	}
	@Id
	@Column(name="eid")
	@GeneratedValue
	private Integer empid;
	@Column(name="ename")
	private String empName;
	@Column(name="esal")
	private Double empSal;
	
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}
	public Employee(Integer empid, String empName, Double empSal) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public Employee() {
		super();
	}
	

}
