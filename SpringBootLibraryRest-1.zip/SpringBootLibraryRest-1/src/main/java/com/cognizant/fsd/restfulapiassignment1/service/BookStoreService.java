package com.cognizant.fsd.restfulapiassignment1.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.fsd.restfulapiassignment1.model.Book;

@Component
public class BookStoreService implements IBookStoreService {

	private static List<Book> books = new ArrayList<Book>();
	
	static {
		//Initialize Data
		
		Book book1 = new Book(1, "Basic Java", 300, 3, LocalDate.of(2016, 2, 12));
		Book book2 = new Book(2, "Advance Java", 400, 4, LocalDate.of(2018, 8, 10));
		Book book3 = new Book(3, "Spring Boot", 500, 5, LocalDate.of(2017, 5, 11));
		Book book4 = new Book(4, "Jenkins", 600, 6, LocalDate.of(2015, 6, 11));
		books.add(book1);
		books.add(book2);
		books.add(book3);
		books.add(book4);
	}
	
	@Override
public void addBook(Book book) {
		System.out.println(">> Inside Service >>");
		books.add(book);
		
	}

	@Override
	public void editBook(Book book,long bookId) {
		Book record = getBookById(bookId);
		books.remove(record);
	book.setBookId(bookId);
		books.add(book);
	}

	@Override
	public boolean deleteBook(long bookId) {
		Book record = getBookById(bookId);
		books.remove(record);
		return Boolean.TRUE;
	}

	@Override
	public Book getBookById(long bookId) {
		return books.stream().filter(b ->b.getBookId() == bookId).findFirst().get();
	}

	@Override
	public List<Book> getAllBooks() {
		return books;
	}

	
}
