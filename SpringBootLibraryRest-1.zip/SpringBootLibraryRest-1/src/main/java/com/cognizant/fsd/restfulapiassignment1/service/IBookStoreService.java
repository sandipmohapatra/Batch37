	package com.cognizant.fsd.restfulapiassignment1.service;
	
	import java.util.List;
	
	import com.cognizant.fsd.restfulapiassignment1.model.Book;
	
public interface IBookStoreService {
	
		public void addBook(Book book);
		public void editBook(Book book,long bookId);
		public boolean deleteBook(long bookId);
		public Book getBookById(long bookId);
		public List<Book> getAllBooks();
	}
