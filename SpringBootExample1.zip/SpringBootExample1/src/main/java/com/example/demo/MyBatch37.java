package com.example.demo;

import org.springframework.stereotype.Component;

@Component("msg")
public class MyBatch37 
{
public void welcome()
{
	System.out.println("Welcome to spring boot");
}
public int sum(int a,int b)
{
	return a+b;
}
}
