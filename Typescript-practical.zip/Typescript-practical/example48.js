var mob = {
    ModelName: "LG",
    RAMsize: "8GB",
    Mpx: "20px",
    Print: function () {
        console.log("Name=" + this.ModelName + "\nRAM=" + this.RAMsize + "\nCamera=" + this.Mpx);
    }
};
mob.Print();
