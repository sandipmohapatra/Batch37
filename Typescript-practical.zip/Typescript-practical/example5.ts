function f1() {
    x = 20;
    console.log(`x=${x}`);
    let x;	// invalid
  }
  f1();
