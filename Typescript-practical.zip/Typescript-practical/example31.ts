let values:string[] = ["A","D","C","B"];
function PrintList(){
    for(var property in values) {
        console.log(`${property}:${values[property]}`);
    }
}
PrintList();
values.sort();
values.reverse();
console.log(`------Sorted List-----`);
PrintList();
