function f1() {
    x = 20;
    console.log("x=" + x);
    var x; // invalid
}
f1();
