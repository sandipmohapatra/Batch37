let username:string = "John"
let age:number = 20;
console.log("Hello !"+ " " + username+" "+"You will be"+ " " + (age+1) + " " +"Next Year");
console.log(`Hello ! ${username} You will be ${age+1} Next Year`);
