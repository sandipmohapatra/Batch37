let values:any[] = new Array();
values[0]= 10;
values[1]= "A";
values[2]= true;
console.log(`${values[0]}\n${values[1]}\n${values[2]}`);
