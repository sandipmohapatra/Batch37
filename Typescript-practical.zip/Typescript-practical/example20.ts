let Name:string = "Samsung TV";
let Price:number|undefined=50000.34;
if(Price==undefined) {
    console.log(`Name=${Name}`);
} else {
    console.log(`Name=${Name}\nPrice=${Price}`);
}
